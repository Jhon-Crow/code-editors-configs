import {classNames} from "@/shared/lib/classNames/classNames";
import cls from './${NAME}.module.scss';
import { useTranslation } from 'react-i18next';
import React, { memo } from 'react';


interface ${NAME}Props {
    className?: string;
}

export const ${NAME} = memo((props: ${NAME}Props) => {

    const { t } = useTranslation();
    
    const {
    className,
    } = props;
    
//    const mods: Mods = {
//        [cls[theme]]: true,
//        [cls.disabled]: disabled,
//    };
    
    return (
        <div className={classNames(cls.${NAME}, {}, [className])}>
            /
        </div>
    );
});