import type { Meta, StoryObj } from '@storybook/react';

import { ${NAME} } from './${NAME}';

const meta: Meta<typeof ${NAME}> = {
    title: 'shared/${NAME}',
    component: ${NAME},
    parameters: {
        layout: 'centered',
    },
    tags: ['autodocs'],
    argTypes: { },
    args: { },
};

export default meta;
type Story = StoryObj<typeof ${NAME}>;

export const Normal: Story = {
    args: { },
};
